import os

project_ids = ['eops-gcp-lab']